package bj;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

// 1개 2개...N개 조합
// tgt[] 없이 재귀호출의 파라미터로 N개의 조합을 만들어가는 과정에서 해결
public class BJ_도영이가만든맛있는음식_2961_2 {
	
	static int N, min;
	static int[][] src;
	
	public static void main(String[] args) throws Exception{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		N = Integer.parseInt(br.readLine());
		src = new int[N][2];
		
		min = Integer.MAX_VALUE;
		
		for (int i = 0; i < N; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			src[i][0] = Integer.parseInt(st.nextToken());
			src[i][1] = Integer.parseInt(st.nextToken());
		}
		
		comb(0, 1, 0);
		
		System.out.println(min);
	}
	
	static void comb(int srcIdx, int sinSum, int ssnSum) {
		
		if( srcIdx == N ) return;
		
		int currSin = src[srcIdx][0] * sinSum;
		int currSsn = src[srcIdx][1] + ssnSum;

		min = Math.min(min, Math.abs(currSin - currSsn));
		
		comb(srcIdx+1, currSin, currSsn);
		comb(srcIdx+1, sinSum, ssnSum);
	}
}
