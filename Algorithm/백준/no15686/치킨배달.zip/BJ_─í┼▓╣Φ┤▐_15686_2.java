package bj;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

// 2차원 배열을 순회하지 않는다.
// 조합으로 선택한 것들과 어떤 것들의 거리 관계 --> 거리를 배열 순회로 찾지 말고, 처음부터 ArrayList 나 2차원 배열을 이용하여 위치 저장
// 치킨거리를 계산할 때, 치킨가게의 순서는 상관없다. ====> 조합
// 치킨가게와 집의 크기가 제시되지 않으므로 Array 를 사용하면 몇 개인지 계산 후 다시 생성 필요 ====> ArrayList 로 동적으로 Add
// 치킨가게를 조합으로 선택 후, 각 조합이 완성되면 치킨 거리를 계산 최저값을 찾는다.
// 치킨 거리를 계산할 때는 집을 기준으로 치킨 거리를 계산하여 가장 적은 값을 찾는다.
// 반대로 치킨가게를 기준으로 계산하면 늘 가장 가까운 집을 선택하게 되어 오류
// comb recursive two recursive way
public class BJ_치킨배달_15686_2 {
	
	static int N, M, min;
	static List<int[]> house, src, tgt;

	public static void main(String[] args) throws Exception{

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		house = new ArrayList<int[]>();
		src = new ArrayList<int[]>();
		tgt = new ArrayList<int[]>();
		
		StringTokenizer st = new StringTokenizer(br.readLine());
	    N = Integer.parseInt(st.nextToken());	//도시크기, 		2 <= N <= 50
	    M = Integer.parseInt(st.nextToken());	//치킨집 선택 최대값,	1 <= M <= 13
	    
	    for(int i=0; i<N; i++){
	    	st = new StringTokenizer(br.readLine());
	        for(int j=0; j<N; j++){
	            int a = Integer.parseInt(st.nextToken());	//0:빈집, 1:집, 2:치킨집
	            if( a == 1) house.add(new int[]{i,j});
	            else if( a == 2) src.add(new int[]{i,j});
	        }
	    }
	    
	    min = Integer.MAX_VALUE;
	    
	    comb(0, 0);
	    
	    System.out.println(min);

	}
	
	//
	static void comb(int srcIdx, int tgtIdx){
		// 치킨 집 선택 조합이 완성되면
	    if(tgtIdx == M){
	    	int sum = 0;
	    	// 치킨 거리 계산
	    	// 모든 집에 대해 각각 모든 치킨집의 거리를 계산하여 가장 가까운 치킨 집을 선택하고 거리를 계산	    	
		    for(int i = 0; i < house.size(); i++){
		    	int dist = Integer.MAX_VALUE;
		        for(int j = 0; j < M; j++){
		            dist = Math.min( 
		            			dist, 
		            			Math.abs(house.get(i)[0] - tgt.get(j)[0]) +
		            			Math.abs(house.get(i)[1] - tgt.get(j)[1])
		            		);
		        }
		        sum += dist;
		    }
		    min = Math.min(min, sum);
	        return;
	    }
	    
	    if(srcIdx == src.size()) return;
	    
	    tgt.add(src.get(srcIdx));
        comb(srcIdx+1, tgtIdx+1);
        tgt.remove(src.get(srcIdx)); 
        comb(srcIdx+1, tgtIdx);
        // 배열 경우는 index 로 덮어쓰지만, ArrayList 는 remove 하지 않으면 계속 add 만 되므로 재귀 호출 후 삭제 해 줌
        
        
	}
}


/*
https://www.acmicpc.net/problem/15686
*/

/*
5 3
0 0 1 0 0
0 0 2 0 1
0 1 2 0 0
0 0 1 0 0
0 0 0 0 2

5



5 2
0 2 0 1 0
1 0 1 0 0
0 0 0 0 0
2 0 0 1 1
2 2 0 1 2

10


...
*/