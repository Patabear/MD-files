package bj;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


// 치킨가게를 조합으로 선택 후, 각 조합이 완성되면 치킨 거리를 계산 최저값을 찾는다.
// 치킨 거리를 계산할 때는 집을 기준으로 치킨 거리를 계산하여 가장 적은 값을 찾는다.
// 반대로 치킨가게를 기준으로 계산하면 늘 가장 가까운 집을 선택하게 되어 오류
// NextPermutation way
// ArrayList 자료구조와 별도로 np 를 위한 index Array를 생성하고, 이를 np 로 가능한 순열을 만들어 내 활용
// 전체 src 크기 만큼의 배열을 만들고 0 초기값, 실제 추출 할 수 만큼만 뒤에 1 로 채움
// 예를 들어 5C2 인 경우, [0,0,0,1,1] 로 설정 후 이 배열을 np 로 돌리면 최종 [1,1,0,0,0] 이 만들어지면서 
// BitMask 처럼 np 의 결과를 이용해서 1인 인덱스를 이용해 src 로부터 선택
public class BJ_치킨배달_15686_3 {
	
	static int N, M;
	static int min = Integer.MAX_VALUE;
	public static List<int[]> house, src;

	static int[] index;
	
	public static void main(String[] args) throws Exception{

		Scanner sc = new Scanner(System.in);
		house = new ArrayList<int[]>();
		src = new ArrayList<int[]>();
		
	    N = sc.nextInt();	//도시크기, 		2 <= N <= 50
	    M = sc.nextInt();	//치킨집 선택 최대값,	1 <= M <= 13

	    for(int i=0; i<N; i++){
	        for(int j=0; j<N; j++){
	            int a = sc.nextInt();	//0:빈집,1:집,2:치킨집
	            if( a == 1) house.add(new int[]{i,j});
	            else if( a == 2) src.add(new int[]{i,j});
	        }
	    }

	    index = new int[src.size()];
	    // 뒤에서부터 M 개만큼 1을 채운다.
	    for (int i = 0; i<M; i++) {
	    	index[(index.length - i) - 1] = 1;
		}
	    // 00011111
	    //System.out.println(Arrays.toString(index));
	    
	    while(true) {
	    	
	    	int sum = 0;
	    	for(int i=0; i<house.size(); i++){
	    		
	    		int dist = Integer.MAX_VALUE;
	    		
	    		for (int j = 0; j < index.length; j++) {
	    			
	    			if( index[j] == 1 ) {
			            dist = Math.min( 
		        			dist, 
		        			Math.abs(house.get(i)[0] - src.get(j)[0]) +
		        			Math.abs(house.get(i)[1] - src.get(j)[1])
	        			);
	    			}
				}
	    		
	    		sum += dist;
	    	}
	    	
	    	min = Math.min(min, sum);
	    	
	    	if( !np() ) break;
	    	
	    }
	    
	    System.out.println(min);
	    sc.close();
	}
	
	
	private static boolean np() {

		int i = index.length - 1;
		while( i>0 && index[i-1]>=index[i] ) --i;
		
		if( i == 0 ) return false;
		
		int j = index.length - 1;
		while(index[i-1]>=index[j])	--j;
		swap(index,i-1,j);
		
		// reverse
		int k = index.length - 1;
		while(i<k) {
			swap(index,i++,k--);			
		}
		return true;
	}
	
	
	private static void swap(int numbers[],int i,int j) {
		int temp = numbers[i];
		numbers[i] = numbers[j];
		numbers[j] = temp;
	}
}


/*
https://www.acmicpc.net/problem/15686
*/

/*
5 3
0 0 1 0 0
0 0 2 0 1
0 1 2 0 0
0 0 1 0 0
0 0 0 0 2

5



5 2
0 2 0 1 0
1 0 1 0 0
0 0 0 0 0
2 0 0 1 1
2 2 0 1 2

10


...
*/